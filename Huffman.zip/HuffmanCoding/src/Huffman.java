import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.*;
import java.util.Enumeration;
import java.util.Vector;

public class Huffman {

	/* 1.Build a huffman tree from input characters
	 * 2.Traverse the huffman tree and assign codes to characters
	 * 3.Print ASCII character followed by the output of the coding module
	 * 
	*/
	
	static HashMap<Integer, Integer> freq = new HashMap<Integer, Integer>(127);
	
	private static int asciiLength = 127;
	
	private static PrintWriter writer = null;

	public static final Scanner keyboard = new Scanner(System.in);

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner NAMEOFFILE = null;
		//Scanner keyboard  = new Scanner(System.in);
		
		
		
		System.out.println("What file do you want to read from");
		
		
		// need to read from text file that the user specifies
		try {
			
			String input = keyboard.next();
			
			NAMEOFFILE = new Scanner(new FileInputStream("res/" + input));
			writer = new PrintWriter("res/output.txt");
			
			
			while(NAMEOFFILE.hasNext())
			{
				String line = NAMEOFFILE.next();
			    convert(line);
			    
				
			}
			System.out.println(freq);
			
			huffmanCoding();
			
			
		}
		
		catch (FileNotFoundException e)
		{
			System.out.println("Problem opening files.");
			System.out.println(e.toString());
			
			System.exit(0);
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
    	System.out.println("IOexception error");
			e.printStackTrace();
		}
		
		NAMEOFFILE.close();
		keyboard.close();
		writer.flush();
        writer.close();
	}
	
	private static Integer spaceCounter = 0;
	
	public static void convert(String text)
	{
		// Here, I will determine the overall frequencies of all printable characters
		// ones that do not appear will recieve a frequency of zero
		// it will also find the corresponding ASCII character 
		
		// split the input word into an array of chars
		char [] a = text.toCharArray();
		
		
		
		System.out.println("The length of the text is " + text.length());
		
			for (int i=0;i<text.length(); i++)
			{
				char c = text.charAt(i);
				char b = text.charAt(i);
				
				Integer ascii = (int)c;
				Integer val = freq.get(ascii);
				//System.out.println(b);
				if( val != null)
				{
					freq.put(ascii, new Integer(val +1));
				}
				else
				{
					freq.put(ascii,  1);
				}
			}
			
			freq.put(32, spaceCounter++);
			
			int j = 0;
			while (j < asciiLength)
			{
				if(freq.get(j) == null)
				{
					freq.put((int)j, 0);
					j++;
				}
				j++;
			}
		
	}
	
	public static void huffmanCoding()
	{
		// implement min heap used as a priority queue
		minHeap heap = new minHeap(freq);
		heap.printQueue();
		
		// extract 2 nodes with the minimum freq from the min heap
		//System.out.println(heap.remove());
		
		Node root = null;
		
		while(heap.getPqueueSize() > 1)
		{
			Node nodeLeft = heap.pollFunc();
			Node nodeRight = heap.pollFunc();
			
			Node newParent = new Node();
			
			newParent.data = nodeLeft.data + nodeRight.data;
			newParent.c = nodeLeft.c + nodeRight.c;
			
			newParent.left = nodeLeft;
			newParent.right = nodeRight;
			
			root = newParent;
			
			heap.add(newParent);
			
 			
		}
		System.out.println("Here are the encoded values");
		printCode(root, " ");
		
		
		
		
	}
	// Print code from geeksforgeeks
	 public static void printCode(Node root, String s) 
	    { 
	        if (root.left == null && root.right == null)
	       { 
	  
	            // c is the character in the node 
	        	System.out.println(root.c + ":" + s);
	        	printWriter(root.c, s);
	 
	            return; 
	        }

	        printCode(root.left, s + "0"); 
 	        printCode(root.right, s + "1");
	    } 

	 public static void printWriter(Integer m, String k)
	 {
		 writer.println(m + ":" + k);
	 }

	

}
