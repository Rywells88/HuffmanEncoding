import java.util.*;
import java.util.Comparator;
import java.util.PriorityQueue;

class The_Comparator implements Comparator<Node> {
	public int compare(Node N1, Node N2) {
		Node first_node;
		Node second_node;
		first_node = N1;
		second_node = N2;

		return first_node.data - second_node.data;
	}

}
class Node{
	Integer data;			// frequency of character
	Integer c;			// ascii code for character
	
	Node left;
	Node right;
}

public class minHeap {

	// Java program to demonstrate working of PriorityQueue

	static PriorityQueue<Node> pQueue = new PriorityQueue<Node>(new The_Comparator());

	public minHeap(HashMap asciiFreq) {
		for (int i = 0; i < asciiFreq.size(); i++) {
			Node newNode = new Node();
			newNode.c = i;
			newNode.data = (Integer) asciiFreq.get(i);
			
			newNode.left = null;
			newNode.right = null;
			
			pQueue.add(newNode);
		}
	}

	public static void main(String args[]) {

		// Removing the top priority element (or head) and
		// printing the modified pQueue using poll()

		// Getting objects from the queue using toArray()
		// in an array and print the array
		Object[] arr = pQueue.toArray();
		System.out.println("Value in array: ");
		for (int i = 0; i < arr.length; i++)
			System.out.println("Value: " + arr[i].toString());
	}

	public void printQueue() {
		// Printing all elements
		System.out.println("The queue elements:");

//		Iterator itr = pQueue.iterator();
//		
//		while (itr.hasNext())
//			System.out.println(itr.next().);
		int i =0;
		while (i< pQueue.size())
		{
			Node[] arr = new Node [127];
			pQueue.toArray(arr);
			
			System.out.println(arr[i].c + " " + arr[i].data);

			
			i++;
		}
		System.out.println();
		System.out.println();
		System.out.println();
	}

	public void checkIfContains(Integer num) {
		boolean b = pQueue.contains(num);
		System.out.println("Priority queue contains  " + num + "or not?: " + b);
	}

	public void remove(Integer remove) {
		pQueue.remove(remove);
	}

	public Node pollFunc() {
		return pQueue.poll();
	}
	public Node peekFunc()
	{
		return pQueue.peek();
	}
	public void add(Node theNode)
	{
		pQueue.add(theNode);
	}
	public int getPqueueSize()
	{
		return pQueue.size();
	}

}
