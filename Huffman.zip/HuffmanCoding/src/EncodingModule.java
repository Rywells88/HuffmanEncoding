import java.util.*;
public class EncodingModule extends Huffman{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Huffman.main(args);
		
	
		
	}
	public EncodingModule()
	{
		super();
		

		
	}

}
